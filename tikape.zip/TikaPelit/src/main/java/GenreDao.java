import java.util.*;
import java.sql.*;

public class GenreDao implements Dao<Genre, Integer> {
    
    private Database database;
    
    public GenreDao(Database database) {
        this.database = database;
    }

    @Override
    public Genre findOne(Integer key) throws SQLException {
        Connection connection = database.getConnection();
        
        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM Genre WHERE id = ?");
        stmt.setObject(1, key);
        
        ResultSet rs = stmt.executeQuery();
        boolean hasOne = rs.next();
        
        if (!hasOne) {
            return null;
        }
        
        int id = rs.getInt("id");
        String genre = rs.getString("genre");
        
        Genre g = new Genre(id, genre);
        
        rs.close();
        stmt.close();
        connection.close();
        
        return g;
    }

    @Override
    public List<Genre> findAll() throws SQLException {
	// ei toteutettu
	return null;
    }

    @Override
    public void delete(Integer key) throws SQLException {
        // ei toteutettu
    }
}