import java.util.List;
import static spark.Spark.*;

public class Main {

    public static void main(String[] args) throws Exception {
        Database database = new Database("peli.db");
        
        GenreDao genreDao = new GenreDao(database);
        PeliDao peliDao = new PeliDao(database);

        List<Peli> pelit = peliDao.findAll();
        
        get("/pelit", (req, res) -> {
          StringBuilder sb = new StringBuilder();
          sb.append("<ul>\n");
          for (Peli p : pelit) {
              String otsikko = p.getOtsikko();
              sb.append("<li>").append(otsikko).append("</li>\n");
          }
          
          sb.append("</ul>\n");
            return sb.toString();
        });
    }
}