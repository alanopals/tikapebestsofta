public class Peli {
    private int id;
    private String otsikko;
    private int genre_id;

    public Peli(int id, String otsikko, int genre_id) {
        this.id = id;
        this.otsikko = otsikko;
        this.genre_id = genre_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOtsikko() {
        return otsikko;
    }

    public void setOtsikko(String otsikko) {
        this.otsikko = otsikko;
    }

    public int getGenre_id() {
        return genre_id;
    }

    public void setGenre_id(int genre_id) {
        this.genre_id = genre_id;
    }
}